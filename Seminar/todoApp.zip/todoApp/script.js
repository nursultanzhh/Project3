document.addEventListener("DOMContentLoaded", () => {
  const ul = document.getElementById("myUL");
  const input = document.getElementById("myInput");
  const addBtn = document.getElementById("addBtn");
  const clearDoneBtn = document.getElementById("clearDoneBtn");

  // Функция создания элемента списка с кнопкой удаления
  const createListItem = (text) => {
    const li = document.createElement("li");
    li.textContent = text;

    const closeBtn = document.createElement("span");
    closeBtn.textContent = "×";
    closeBtn.className = "close";
    li.append(closeBtn);

    return li;
  };

  // Добавление одной задачи 
  const addTaskToList = (text) => {
    ul.append(createListItem(text));
  };

  // Инициализация — здесь можно добавить стартовые задачи или оставить пустым
  const init = () => {
    // Например, можно добавить demo-задачу:
    // addTaskToList("Демо: Первая задача");
  };

  // Привязка обработчиков событий
  const bindEvents = () => {
    // ===== TASK 1 =====

    // ===== TASK 2 =====

    // ===== TASK 3 =====

    // ===== TASK 4 =====
    
  };

  // Запуск приложения
  init();
  bindEvents();
});
